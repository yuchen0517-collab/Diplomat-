(function(){
  'use strict';
  var KIND={D01:'scandal',D02:'technology',D03:'conflict',D04:'conflict',D05:'diplomacy',D06:'disaster',D07:'economy',D08:'technology',G01:'diplomacy',G02:'scandal',G03:'diplomacy',G04:'economy',G05:'diplomacy',G06:'conflict'};
  var history=[],panel=null,listEl=null,countEl=null;
  function esc(value){return String(value==null?'':value).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function normalize(ev,st,raw){
    ev=ev||{};st=st||{};raw=raw||'';
    var id=ev.id||'EVENT';
    return{
      id:id,
      kind:ev.kind||KIND[id]||'disaster',
      title:ev.title||raw.replace(/^⚡?\s*突发[:：]?\s*/,'').split('·')[0].trim()||'突发事件',
      text:ev.text||raw||'本局已发生该事件。',
      flavor:ev.flavor||'',
      round:ev.round||st.round||'—',
      effects:ev.effects||{},
      impacts:Array.isArray(ev.impacts)?ev.impacts:null,
      noEffect:!!ev.no_effect,
      playerLabel:ev.playerLabel||st.player_label||'我方',
      agentLabel:ev.agentLabel||st.speaker_label||st.agent_label||'对方'
    };
  }
  function ensurePanel(){
    if(panel&&panel.isConnected)return true;
    var railMode=document.body.classList.contains('is-observe')||document.body.classList.contains('is-duel-commentary');
    var host=railMode?document.querySelector('.v18-narrator'):document.querySelector('.sidebar-left');
    if(!host)return false;
    var anchor=railMode?host.querySelector('.v18-auto-card'):host.querySelector('.sidebar-footer');
    panel=document.createElement('section');
    panel.className='ec-history';
    panel.setAttribute('aria-label','事件卡历史');
    panel.innerHTML='<div class="ec-history-head"><span class="ec-history-title">事件卡</span><span class="ec-history-en">EVENT LOG</span><span class="ec-history-count" id="ecHistoryCount">0</span></div><div class="ec-history-list" id="ecHistoryList"></div>';
    host.insertBefore(panel,anchor||null);
    listEl=panel.querySelector('#ecHistoryList');
    countEl=panel.querySelector('#ecHistoryCount');
    panel.addEventListener('click',function(e){
      var button=e.target.closest?e.target.closest('[data-ec-history]'):null;
      if(!button)return;
      var item=history[Number(button.getAttribute('data-ec-history'))];
      if(item&&window.NegotiationEventCard)window.NegotiationEventCard.show(item);
    });
    return true;
  }
  function renderHistory(){
    if(!ensurePanel())return;
    countEl.textContent=String(history.length);
    if(!history.length){listEl.innerHTML='<div class="ec-history-empty">暂未触发事件</div>';return;}
    listEl.innerHTML=history.map(function(ev,index){
      return'<button type="button" class="ec-history-item" data-ec-history="'+index+'" title="回看：'+esc(ev.title)+'"><span class="ec-history-name">'+esc(ev.title)+'</span><span class="ec-history-round">R'+esc(ev.round)+'</span></button>';
    }).reverse().join('');
  }
  function addHistory(ev){
    var key=ev.id+'|'+ev.round+'|'+ev.title;
    for(var i=0;i<history.length;i++)if(history[i]._key===key)return;
    ev._key=key;
    history.push(ev);
    renderHistory();
  }
  function syncState(){
    var st=window.Negotiation&&window.Negotiation.state;
    if(!st)return;
    (st.events||[]).forEach(function(ev){addHistory(normalize(ev,st,''));});
  }
  function show(el){
    if(!window.NegotiationEventCard||!el||el.nodeType!==1||!el.classList.contains('msg-system'))return;
    if(el.getAttribute('data-event-card')==='1'||!/⚡|突发/.test(el.textContent||''))return;
    el.setAttribute('data-event-card','1');
    var raw=String(el.textContent||'').trim();
    var st=window.Negotiation&&window.Negotiation.state;
    var events=(st&&st.events)||[],ev=null;
    for(var i=events.length-1;i>=0;i--){
      if(events[i].title&&raw.indexOf(events[i].title)!==-1){ev=events[i];break;}
    }
    var event=normalize(ev,st,raw);
    addHistory(event);
    window.NegotiationEventCard.show(event);
  }
  function scanAdded(nodes){Array.prototype.forEach.call(nodes,show);}
  function start(){
    renderHistory();
    syncState();
    var chat=document.getElementById('chatMessages');
    if(!chat||chat.__eventCardObserver)return;
    chat.__eventCardObserver=true;
    var observer=new MutationObserver(function(mutations){
      mutations.forEach(function(mutation){scanAdded(mutation.addedNodes);});
    });
    observer.observe(chat,{childList:true});
    setInterval(syncState,1500);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);
  else start();
  window.NegotiationEventCardIntegration={show:show,history:function(){return history.slice();}};
})();
