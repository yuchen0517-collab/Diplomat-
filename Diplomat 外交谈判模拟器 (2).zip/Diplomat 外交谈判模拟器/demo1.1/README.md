# 谈判对手 Agent 引擎

本目录是 Diplomat 外交谈判模拟器的 Agent 核心，同时保留命令行运行方式。网页后端 `../server.py` 会直接导入 `neg_cli.py`，复用 Prompt 构建、知识库注入、模型调用、JSON 修复、输出校验和指数结算逻辑。

## 文件说明

| 文件 | 作用 |
|---|---|
| `neg_cli.py` | Agent 主程序；网页引擎与命令行入口共用 |
| `谈判对手Agent_prompt.md` | 角色设定、输出 JSON 格式、指数规则与评分标准 |
| `agents.json` | 场景、议程、代表团人设、立场、红线与初始指数 |
| `test_validate.py` | JSON 异常、指数边界、评分与 Prompt 注入测试 |
| `report.py` | 读取命令行对局日志并生成分析报告 |
| `run.bat` / `report.bat` | Windows 命令行启动器 |
| `logs/` | 运行命令行对局后自动生成的日志目录，不需预先创建 |

## 运行方式

在提交包根目录执行：

```powershell
# 检查 agents.json 与 Prompt 占位符
py -3 demo1.1/neg_cli.py --check

# 无需密钥，运行内置离线对局
py -3 demo1.1/neg_cli.py --offline

# 执行边界测试
py -3 demo1.1/test_validate.py
```

也可以进入本目录后双击 `run.bat`。命令行版首次运行会生成 `logs/`，网页版不会写入该目录。

## 真实模型

```powershell
$env:DEEPSEEK_API_KEY = "你的 API Key"
py -3 demo1.1/neg_cli.py --rounds 5
```

可选参数：

```powershell
py -3 demo1.1/neg_cli.py --agent eu          # 切换对手
py -3 demo1.1/neg_cli.py --interactive       # 手动输入我方发言
py -3 demo1.1/report.py demo1.1/logs/run-xxx.json
```

真实模型使用需要网络与有效密钥；提交评审可直接使用 `--offline`。

## 修改入口

| 需求 | 修改位置 |
|---|---|
| 调整代表团语气、人设、立场或红线 | `agents.json` |
| 调整谈判主题、议程、事件或博弈场景 | `agents.json` 的 `_scenario` |
| 调整 Agent 输出格式与规则 | `谈判对手Agent_prompt.md`，必要时同步修改 `neg_cli.py` 校验逻辑 |
| 调整三指数单轮变化上限 | `neg_cli.py` 的 `DELTA_LIMIT` |
| 调整评分权重 | `neg_cli.py` 的 `SCORE_WEIGHTS`，并同步 Prompt |
| 新增议题知识库映射 | `neg_cli.py` 的 `TOPIC_ALIAS` 与 `../knowledge/topics/` |

修改配置后请先运行 `--check` 与 `test_validate.py`。
